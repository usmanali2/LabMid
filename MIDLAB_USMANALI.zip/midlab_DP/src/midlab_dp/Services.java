/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midlab_dp;

/**
 *
 * @author Usman Ali
 */
public class Services implements ServicesType {
    protected PersonalDetails user;
    
    public Services(PersonalDetails user){
        this.user = user;
    }
    String[] Policies=new String[1000];
    int length=0;
    @Override
    public void getPolicies() {
        
        System.out.println("Policies are:");
       for(int i=0;i<length;i++){
           
       System.out.println("Policies "+(i+1)+":"+Policies[i]);

       
       } 
      
    }
    
    @Override
    public void addPolicies(String newPolicies){
        Policies[length]=newPolicies;
       length++; 
    }

    @Override
    public void getUserDetails() {
        System.out.println("Name:"+user.getName());
        System.out.println("Gender:"+user.getGender());
        System.out.println("NAtionality:"+user.getNationatily());
        System.out.println("Age:"+user.getAge());
        System.out.println("Purpose:"+user.getPurpose());

        
        
    }
}
