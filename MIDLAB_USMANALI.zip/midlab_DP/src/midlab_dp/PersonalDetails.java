/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package midlab_dp;

/**
 *
 * @author Usman Ali
 */
public class PersonalDetails {
    
    String name,Nationatily,gender,purpose;
    int age;
    
    
   public PersonalDetails(String name,String Nationality,int age,String purpose,String gender){
   this.name = name;
   this.Nationatily = Nationality;
   this.age = age;
   this.purpose= purpose;
   this.gender= gender;
   }

    public String getName() {
        return name;
    }

    public String getNationatily() {
        return Nationatily;
    }

    public String getGender() {
        return gender;
    }

    public String getPurpose() {
        return purpose;
    }

    public int getAge() {
        return age;
    }
   
}
