/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package midlab_dp;

/**
 *
 * @author Usman Ali
 */
public abstract class ICMPservices {
    protected ServicesType services;
    protected ICMPservices(ServicesType Services){
    this.services = Services;
    }
    abstract public void getUserDetails();
    abstract String[] getPolicies();
    abstract void addPolicies(String newPolicies);
}
