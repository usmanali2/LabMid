/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package midlab_dp;

/**
 *
 * @author Usman Ali
 */
public class Main {  

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PersonalDetails user = new PersonalDetails("Zeeshan Habib","Pakistan",30,"Working","Male");
        
        ServicesType services;
        services = new Services(user);
        services.addPolicies("All Traveler have to Attaced their Pictures along with their passport");
        services.addPolicies("All Traveler have to their Passport");
        services.addPolicies("All Traveler have to bring their Credentials must");
        services.getUserDetails();
       services.getPolicies();
        
    }
    
}
